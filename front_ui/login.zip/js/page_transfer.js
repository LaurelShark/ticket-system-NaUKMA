function goToPage(page)
{
	window.location.replace(page);
}