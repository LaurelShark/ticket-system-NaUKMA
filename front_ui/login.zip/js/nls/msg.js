define({
  'root': true,
  'ru': true
});
