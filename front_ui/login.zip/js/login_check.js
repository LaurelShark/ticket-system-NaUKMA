function check_login()
{
    var username = document.getElementById('login').value;
    var pass = document.getElementById('pass').value;
    
    //now check if username and passwords are valid
    var valid = false
    
    if (valid)
    {
        //go to user page
    }
    else
    {
        document.getElementById('error_msg').innerHTML = "Неправильне ім'я користувача та/або пароль"
    }
}